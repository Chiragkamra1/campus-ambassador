# The goal was to develop a Campus/Community Ambassador Management Portal


The proposed solution is that we use Node and Express JS to handle the backend of our application with the help of these two, we are able to add functionalities in our web application such as:
- Authentication require for Login and Registration.
- Storage of user credentials.
- Selection and rejection of candidates based on their resume
- Sending Emails to the selected candidates along with their credentials to access the portal.
- Dispatching new time real notifications.
- Receiving feedback from the users.

http://innerve-hacks.herokuapp.com  (Currently offline)
